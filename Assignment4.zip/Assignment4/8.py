import os

current_directory = os.getcwd()
print(f"Current working directory: {current_directory}")
