import random

min_value = 10.2
max_value = 2.5

random_float = random.uniform(min_value, max_value)

print(f"Generated random floating number: {random_float}")
